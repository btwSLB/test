let offset = 0;
const sliderLine = document.querySelector('.slider-line');
let interval;

function nextSlide() {
    offset = offset + 1440;
    if (offset > 7200) {
        offset = 0;
    }
    sliderLine.style.left = -offset + 'px';
}


interval = setInterval(nextSlide, 3000);


document.querySelector('.slider-line').addEventListener('click', function() {
    clearInterval(interval);
});