from django.contrib import admin
from .models import categories, price, photo, ourwork, photograf, record

admin.site.register(categories)

admin.site.register(photo)

admin.site.register(ourwork)

admin.site.register(photograf)

@admin.register(record)
class CourseAdmin(admin.ModelAdmin):
    list_filter = ("stat", )
    list_display = ("datatime","date", "time",'time_finish',"nf","name","login","stat","reason")

@admin.register(price)
class CourseAdmin(admin.ModelAdmin):
    list_display = ("name", "namet","clock","price")