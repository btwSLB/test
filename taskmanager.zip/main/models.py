from django.db import models

class price(models.Model):
    name = models.TextField('Название')
    namet = models.TextField('Название тарифа')
    clock = models.TimeField('Продолжительность(в часах)')
    price = models.IntegerField('Цена')
    opis = models.TextField('Описание')

class ourwork(models.Model):
    name = models.TextField('Название')

    def __str__(self):
        return self.name

class categories(models.Model):
    name = models.TextField('Название')
    albom = models.TextField("Название альбома")

    def __str__(self):
        return self.albom

class photo(models.Model):
    way = models.ImageField('Фотография', upload_to='main/static/img/albom')
    albom = models.TextField("Название альбома")

class users(models.Model):
    name = models.TextField('Имя')
    fname = models.TextField('Фамилия')
    oname = models.TextField('Отчество(не обязательно',blank=True)
    login = models.TextField('Логин')
    email = models.EmailField('Email')
    password = models.TextField('Пароль')


class photograf(models.Model):
    nf = models.TextField('Имя и Фамиля')

    def __str__(self):
        return self.nf

class record(models.Model):
    date = models.DateField('Дата начала фотосессии')
    time = models.TimeField('Время начала фотосессии')
    time_finish = models.TimeField('Время окончания фотосесии')
    nf = models.TextField("Фотограф")
    name = models.TextField("Тариф")
    datatime = models.DateTimeField("Таймспат")
    login = models.TextField("Логин юзера")
    statlist=(
        ("Новый","Новый"),
        ("Отменен","Отменен"),
        ("Подтвержден","Подтвержден"),
        )

    stat=models.CharField("Статус заказа",choices=statlist,max_length=11)

    reason=models.TextField("Причина отмены",blank=True)

    def __str__(self):
        return self.name