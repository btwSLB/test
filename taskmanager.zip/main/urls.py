from django.urls import path
from . import views

urlpatterns = [
    path('',views.about,name='about'),
    path('contacts',views.contacts,name='contacts'),
    path('ourwork',views.our_work,name='ourwork'),
    path('categories/<name>',views.categorie,name='categories'),
    path('fotos/<albom>',views.fotos,name='foto'),
    path('price',views.products,name='price'),
    path('register',views.register,name='register'),
    path('login',views.login,name='login'),
    path('logout',views.logout,name='logout'),
    path('oform',views.oform,name="oform"),
    path('confirmatiom',views.confirmation,name="confirmation"),
    path('records',views.listrecords,name="records"),
    path('delete/<id>',views.delete,name="delete"),
]