from django.shortcuts import render
from .models import categories, photo, ourwork, price, users,photograf, record, categories
from django.db.models import Q
from datetime import datetime, timedelta
user=False

def about(request):
    global user
    jij=photograf.objects.order_by("id")
    s = categories.objects.order_by("-id")
    p = {}
    po = []
    for i in s:
        name=i.name
        if name not in p:
            p[name]=i
    for i in range(5):
        po.append(list(p.values())[i])
    return render(request,'main/about-us.html',{'user':user,'g':jij,'p':po})


def contacts(request):
    global user
    return render(request,'main/contacts.html',{'user':user})


def our_work(request):
    global user
    cart = ourwork.objects.all()
    return render(request,'main/ourwork.html',{'cart':cart,'user':user})


def categorie(request,name):
    global user
    cart = categories.objects.filter(name=name)
    return render(request,'main/categorie.html',{'cart':cart,'user':user})


def fotos(request,albom):
    global user
    cart = photo.objects.filter(albom=albom)
    return render(request, 'main/foto.html',{"cart":cart,'user':user})


def products(request):
    global user
    photografs=photograf.objects.all()
    cart = price.objects.order_by('id')
    return render(request, 'main/price.html',{"cart":cart,'user':user,'photo':photografs})

def register(request):
    global user
    if request.method == "POST":
        goga = request.POST
        if goga['password']==goga['password2']:
            if users.objects.filter(Q(login=goga['login'])|Q(email=goga['email'])):
                error='Человек с таким телефоном почтой или логином уже существует!'
            else:
                d= users.objects.create(name=goga['name'],fname=goga['fname'],oname=goga['oname'],login=goga['login'],email=goga['email'],password=goga['password'])
                error='Вы успешно зарегистрированы!'
        else:
            error='Пароли не совпадают!'
        return render(request,'main/register.html',{'goga':error,'user':user})
    else:
        return render(request,'main/register.html',{'user': user })


def login(request):
    global user
    if request.method== "POST":
        jojo=request.POST
        ggg=users.objects.filter(login=jojo['login'],password=jojo['password'])
        if ggg:
            erorr="Вы успешно зашли"
            user=jojo['login']
        else:
            erorr="Таково клиента не существует"

        return render(request,'main/login.html',{'jojo':erorr,'user':user})
    else:
         return render(request,'main/login.html',{'user':user})


def logout(request):
    global user
    if user !=False:
        user=False
        return render(request,'main/about-us.html',{'user':user})
    else:
        return render(request,'main/about-us.html',{'user':user})


def oform(request):
    global user
    if user != False:
        pricetime = request.GET.get('time')
        g = request.GET.get('sort')
        nf = request.GET.get('nf')
        ara=""
        if g == 'none':
            k = "Вы не выбрали фотографа"
            return render(request, 'main/oform.html', {'user': user, 'ggg': k, 'g': g})
        else:
            all_time = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00']
            yesterday = datetime.today() + timedelta(days=1)
            min_day_value = yesterday.strftime("%Y-%m-%d")

            if request.GET.get('date') is None:
                dict_obj = {
                    'user': user,
                    'h': nf,
                    'min_day_value': min_day_value,
                    'all_time': all_time,
                    'g': g,
                    'step_1': True,
                    'step': 'Шаг 1',
                    'pricetime': pricetime,
                }
                return render(request, 'main/oform.html', dict_obj)
            else:
                apps = record.objects.filter(date=request.GET.get('date'), nf=request.GET.get('photograf')).all()#идет фильтрация даты и фотографа с базой данных
                for obj in apps:
                    start_time = datetime.combine(obj.date, obj.time)#Начало фотоссесии
                    end_time = datetime.combine(obj.date, obj.time_finish)#Конец фотосессии
                    if start_time.strftime("%H:%M") not in all_time:#проверка если нету его
                            ara = "На эту дату нельзя записаться так как продолжительность услуги заходит за грань нашего распиная,Запишитесь на другую дату"
                    elif end_time.strftime("%H:%M") not in all_time:#проверка если нету его
                            ara = "На эту дату нельзя записаться так как продолжительность услуги заходит за грань нашего распиная,Запишитесь на другую дату"
                    else:
                        while start_time < end_time:
                            all_time.remove(start_time.strftime("%H:%M"))#удаление значения из списка
                            start_time += timedelta(hours=1)#к переменной добавляется +1 час что бы у
                
                if all_time != []:
                    dict_obj = {
                        'user': user,
                        'h': request.GET.get('h'),
                        'min_day_value': min_day_value,
                        'all_time': all_time,
                        'g': request.GET.get('photograf'),
                        'step_1': False,
                        'step_2': True,
                        'step': 'Шаг 2',
                        'choch': request.GET.get('date'),
                        'pricetime': request.GET.get('pricetime'),
                        'ara':ara if ara else None 
                    }
                else:
                    dict_obj = {
                        'user': user,
                        'step_1': False,
                        'step_2': True,
                        'step': 'Шаг 2',
                        'er': 'Выберите другую дату'
                    }
                return render(request, 'main/oform.html', dict_obj)
    else:
        return render(request, 'main/about-us.html', {'user': user})
        


def confirmation(request):
    global user
    if user != False:
        if request.method == 'POST':
            NF = request.POST['h']
            date = request.POST['date']
            time = request.POST['time']
            photograf = request.POST['photograf']
            pricetime = request.POST['pricetime']

            # Преобразуем строковое время в объект timedelta
            time_delta = timedelta(hours=int(time.split(':')[0]), minutes=int(time.split(':')[1]))
            
            # Преобразуем строковое время из pricetime в объект timedelta
            pricetime_delta = timedelta(hours=int(pricetime.split(':')[0]), minutes=int(pricetime.split(':')[1]))

            # Сложим время и pricetime
            time_off = (datetime.min + time_delta + pricetime_delta).time().strftime("%H:%M")

            error = "Поздравляем с успешной записью"
            plus=record.objects.create(date=date,time=time,name=NF,nf=photograf,datatime=datetime.today(),login=user,stat="Новый",time_finish=time_off)
            return render(request, 'main/confirmation.html', {'user': user, 'error': error})
    else:
        return render(request, 'main/about-us.html', {'user': user})
    

def listrecords(request):
    global user
    if user!=False:
        rec=record.objects.filter(login=user).order_by("-datatime")
        return render(request,'main/list-records.html',{'user':user,"rec":rec})
    else:
        return render(request,'main/about-us.html',{'user':user})
    

def delete(request,id):
    global user
    s= record.objects.filter(Q(login=user) & Q(id=id))
    if s:
        record.objects.filter(Q(login=user) & Q(id=id)).delete()
        erorr="Заказ отменен"
    else:
        erorr="Такого заказа не существует"
    
    return render(request,'main/delete.html',{'user':user,'erorr':erorr})
